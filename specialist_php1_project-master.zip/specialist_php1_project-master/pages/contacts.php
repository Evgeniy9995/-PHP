<div class="main__center">
    <div class="main__center-heading">
        <h1 class="align-center">Контакты</h1>
    </div>
</div>
