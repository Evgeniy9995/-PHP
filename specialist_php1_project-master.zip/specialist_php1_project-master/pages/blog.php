<div class="main__center">
    <div class="main__center-heading">
        <h1 class="align-center">Блог</h1>
    </div>
</div>
<a href="#section" class="mouse_btn font-green">
    <span class="ion ion-mouse"></span>
</a>
<section id="section" class="section">
    <h2 class="section__title">Последние посты</h2>
    <article>
        <div class="section__about">
            <h3>Статья 2</h3>
            <p>
                Lorem ipsum dolor sit amet, in quodsi vulputate pro. Ius illum vocent mediocritatem an, cule dicta iriure at. Ubique maluisset vel te,
                his dico vituperata ut. Pro ei phaedrum maluisset. Ex audire suavitate has, ei quodsi tacimates sapientem sed, pri zril ubique ut. Te
                cule tation munere noluisse. Enim torquatos ne pri, eum mollis salutandi corrumpit et, fugit apeirian duo ad.
            </p>
        </div>
    </article>
    <article>
        <div class="section__about">
            <h3>Статья 1</h3>
            <p>
                Lorem ipsum dolor sit amet, in quodsi vulputate pro. Ius illum vocent mediocritatem an, cule dicta iriure at. Ubique maluisset vel te,
                his dico vituperata ut. Pro ei phaedrum maluisset. Ex audire suavitate has, ei quodsi tacimates sapientem sed, pri zril ubique ut. Te
                cule tation munere noluisse. Enim torquatos ne pri, eum mollis salutandi corrumpit et, fugit apeirian duo ad.
            </p>
        </div>
    </article>
</section>