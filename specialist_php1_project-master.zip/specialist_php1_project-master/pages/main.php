<div class="main__center">
    <div class="main__center-heading">
        <h1>Привет! Меня зовут <?= $fullName ?></h1>
        <p>Я <?= $me['profession'] ?></p>
    </div>
</div>
