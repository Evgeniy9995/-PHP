<?php

$me = [
    'name'       => 'Александр',
    'surname'    => 'Пантелеев',
    'profession' => 'профессиональный разработчик php',
    'contacts'   => [
        'tel'   => '+7(990)-00-00-00',
        'email' => 'apanteleev@specialist.ru'
    ],
];

$navigation = [
    ['link' => 'main', 'name' => 'Главная'],
    ['link' => 'resume', 'name' => 'Резюме'],
    ['link' => 'blog', 'name' => 'Блог'],
    ['link' => 'contacts', 'name' => 'Контакты'],
];